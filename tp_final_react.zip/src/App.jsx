import NavBar from "./Componentes/NavBar.jsx";
import { BrowserRouter as Router } from "react-router-dom";
import Public from "./Routes/Rutas.jsx";
import Container from "react-bootstrap/Container";

const estilo = {  
  texto: {
    margin: '20px 70px',
    padding: '15px 15px',
    textAlign: 'center',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontSize: '20px',   
    backgroundColor: 'darkgoldenrod'
  },
  paginas: {
    paddingTop: '80px'
  }
}

function App() {
  return (
    <>
      <Router>
        <NavBar />        
        <Container style={estilo.paginas}>
          <Public />
        </Container>
        <h3 style={estilo.texto}>Trabajo practico final</h3>   
      </Router>
    </>
  );
}

export default App;
