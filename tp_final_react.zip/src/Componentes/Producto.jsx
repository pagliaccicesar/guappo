import { Link } from "react-router-dom";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

const styles = {
  card: { 
    marginBottom: "10px", 
    marginTop: "5px",
    margin: "10px",
    width: "100%",
    display: "inline-block",
    maxWidth: "300px"
  },
};

function Producto({ id, title, price, thumbnail }) {
  return (
    <Card style={styles.card}>
      <Card.Img variant="top" src={thumbnail} />
      <Card.Body>
        <Card.Title>{title}</Card.Title>
        <Card.Text>{id}</Card.Text>
        <Card.Text>$ {price}</Card.Text>
        <Button as={Link} to={`/producto/${id}`} variant="secondary">
          Ver detalle
        </Button>
      </Card.Body>
    </Card>
  );
}

export default Producto;
