import { Button, Spinner } from "react-bootstrap";

function ButtonSpinner({
  variant = "secondary",
  type = "submit",
  label,
  loading,
}) {
  return (
    <Button variant={variant} type={type} disabled={loading}>
      {loading && <Spinner animation="grow" size="sm" />}
      {label}
    </Button>
  );
}

export default ButtonSpinner;
