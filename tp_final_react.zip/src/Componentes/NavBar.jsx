import { Link } from "react-router-dom";
import { Nav, Navbar } from "react-bootstrap";

const estilo = {  
   menu: {
      position: 'fixed',
      width: '100%',    
      zIndex: '100',
      padding: "26px",
      justifyContent: "center",
      alignContent: "center"
    }
}

function NavBar() {
  return (
    <Navbar bg="dark" data-bs-theme="dark" style={estilo.menu}>     
      <Navbar.Toggle aria-controls="basic-navbar-nav"/>      
        <Nav className="me-auto" style={estilo.menu}>
          <Nav.Link as={Link} to={"/"}>
            Inicio
          </Nav.Link>
          <Nav.Link as={Link} to={"/ingresar"}>
            Ingresar
          </Nav.Link>
          <Nav.Link as={Link} to={"/alta"}>
            Registrarse
          </Nav.Link>         
        </Nav>    
    </Navbar>    
  );
}

export default NavBar;

