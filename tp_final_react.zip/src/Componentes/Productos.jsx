import { useState, useEffect } from "react";
import Producto from "./Producto.jsx";
import { getProductos } from "../Servicios/Servicio.js";

function Productos() {  
  const [productos, setProductos] = useState([]);
  const [loading, setLoading] = useState(true);
 
  useEffect(() => {
    const request = async () => {
      try {
        const data = await getProductos();
        setProductos(data);
        setLoading(false);
      } catch (error) {
        console.log(error);
      }
    };
    request();
  }, []); 

  if (loading) {
    return <div>Cargando...</div>;
  } else {
    return (
      <div>
        {productos.map((producto) => (
          <Producto
            key={producto.id}
            id={producto.id}
            title={producto.title}
            price={producto.price}           
            thumbnail={producto.thumbnail}            
          />          
        ))}       
      </div>
    );
  }
}

export default Productos;
