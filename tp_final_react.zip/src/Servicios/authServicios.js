import firebase from "../Config/firebase";

export const create = async (data) => {
  const responseUser = await firebase
    .auth()
    .createUserWithEmailAndPassword(data.email, data.password);
  if (responseUser) {    
    await firebase.firestore().collection("usuarios").add({
      name: data.name,
      lastname: data.lastname,
      userId: responseUser.user.uid,
    });
    return responseUser.user.uid;
  }
};

export const authenticate = async (email, password) => {
  return firebase.auth().signInWithEmailAndPassword(email, password);
};
