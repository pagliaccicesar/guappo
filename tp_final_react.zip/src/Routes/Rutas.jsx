import Home from "../Paginas/Home.jsx";
import Detalle from "../Paginas/Detalle.jsx";
import Login from "../Paginas/Login.jsx";
import Registro from "../Paginas/Registro.jsx";
import NoEncontrado from "../Paginas/NoEncontrado.jsx";
import { Route, Routes } from "react-router-dom";

function Rutas() {
  return (
    <>
      <Routes>
          <Route path="/" element={<Home />} />       
          <Route path="/ingresar" element={<Login />} />
          <Route path="/alta" element={<Registro />} />      
          <Route path="/producto/:id" element={<Detalle />} />
          <Route path="*" element={<NoEncontrado />} />
      </Routes>
    </>
  );
}

export default Rutas;
