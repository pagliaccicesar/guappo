import Productos from "../Componentes/Productos.jsx";
import "./Home.css";

function Home() {  
  return (
    <div>
      <h1>Nuestros Productos</h1>
      <Productos />
    </div>
  );
}

export default Home;
