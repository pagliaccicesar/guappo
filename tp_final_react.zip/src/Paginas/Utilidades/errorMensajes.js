export const registroErrorMessage = {    
    "auth/email-already-in-use": "El email que ingresó ya está en uso.",
    "auth/invalid-credential": "Hay un dato mail ingresado"    
};