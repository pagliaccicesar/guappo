function NoEncontrado() {
    return <>
    <h3>No se encontro</h3>
    </>;
  }
  
  export default NoEncontrado;
  