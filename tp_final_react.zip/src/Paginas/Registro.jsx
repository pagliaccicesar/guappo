import { useForm } from "react-hook-form";
import ButtonSpinner from "../Componentes/Spinner";
import Form from "react-bootstrap/Form";
import { useState } from "react";
import { create } from "../Servicios/authServicios";
import Input from "../Componentes/Input";
import AlertNavigation from "../Componentes/Alerta";
import { registroErrorMessage } from "./Utilidades/errorMensajes";


const estilo = {  
  texto: {
     textAlign: 'center',
     fontFamily: 'Arial, Helvetica, sans-serif',
     fontSize: '25px',   
     backgroundColor: 'darkgoldenrod'
  },
  hoja: {
     padding: '0 200px'
  }
}

function Registro() {
  const [loading, setLoading] = useState(false);
  const [alertNavigation, setAlertNavigation] = useState({
    message: "",
    variant: "",
  });
  const onSubmit = async (data) => {
    setLoading(true);
    try {
      const responseUser = await create(data);
      setLoading(false);
      setAlertNavigation({
        message: "Se registro el usuario exitosamente!",
        variant: "info",
        duration: 1000,
        link: "/ingresar",
      });
      console.log("🚀 ~ onSubmit ~ responseUser:", responseUser);
    } catch (e) {
      console.log("🚀 ~ onSubmit ~ e:", e.code);
      setLoading(false);
      setAlertNavigation({
        message: registroErrorMessage[e.code] || "Hay un dato mal ingresado",
        variant: "danger",
      });
    }
  };
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ mode: "onChange" });
  return (
    <>
    <h2 style={estilo.texto}>Registrarse</h2>
      <Form onSubmit={handleSubmit(onSubmit)}style={estilo.hoja}>
        <Input name="name" placeholder="Ingrese nombre"
          register={{ ...register("name"),
          required: true
         }}
        />        

        <Input name="lastname" placeholder="Ingrese apellido"
          register={{ ...register("lastname"),
          required: true
        }}
        />

        <Input type="email" name="email" placeholder="Ingrese email"
          register={{
            ...register("email", {
              required: true,
              pattern:
                /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/i,
            }),
          }}
          errors={errors}
        />

        <Input type="password" name="password"
          placeholder="Ingrese su contraseña"
          register={{
            ...register("password", {
              required: true,
              minLength: 6,
              maxLength: 12,
            }),
          }}
          errors={errors}
        >
          {errors?.password?.type === "minLength" && (
            <Form.Text className="text-danger">Debe escribir como minimo 6 caracteres</Form.Text>
          )}
          {errors?.password?.type === "maxLength" && (
            <Form.Text className="text-danger">Debe escribir hasta 12 caracteres</Form.Text>
          )}
        </Input>
        <ButtonSpinner label="Registrarse" loading={loading}/>
        <AlertNavigation {...alertNavigation}/>
      </Form>
    </>
  );
}

export default Registro;
