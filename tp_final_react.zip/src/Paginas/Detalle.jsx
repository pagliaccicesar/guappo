import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getProductosById } from "../Servicios/Servicio";
import { useNavigate } from "react-router-dom";

const estilo = {
  boton: {
    display: 'block',
    margin: '0 auto',
    padding: '13px',
    color: 'red',
    fontWeight: 'bold',
    borderRadius: '5%'
  },
  texto: {
    color: 'blue',
    fontSize: '1.5rem',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  identificador: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: '1em',
    textAlign: 'center'
  },
  precio: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: '1.2em',
    textAlign: 'center'
  },
  imagen: {
    display: 'inline',
    cursor: 'pointer'
  }
}

function Detalle() {
  const { id } = useParams();
  const [producto, setProducto] = useState([]);
  const [loading, setLoading] = useState(true);
  const [comprar, setComprar] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const request = async () => {
      try {
        const response = await getProductosById(id);
        setProducto(response);
        setLoading(false);
      } catch (e) {
        navigate("/not-found");
      }
    };
    request();
  }, [id, navigate]);

  const handleClick = () => {
    setComprar(true);
    setTimeout(() => {
      setComprar(false);
    }, 2000);
  };

  if (loading) {
    return <div>Cargando ...</div>;
  } else {
    const { title, price, pictures } = producto;
    return (
      <div>
        <p style={estilo.texto}>{title}</p>
        <p style={estilo.identificador}>{id}</p>
        <p style={estilo.precio}>$ {price}</p>
        <div style={estilo.imagen}>
          {pictures.map(({ id, secure_url }) => (
            <img key={id} src={secure_url} alt=""/>
          ))}
        </div>
        <div>
          <button style={estilo.boton} onClick={handleClick}>Comprar</button>
        </div>
        {comprar && (
          <p style={estilo.precio}>Próximamente</p>
        )}
      </div>
    );
  }
}

export default Detalle;


  
