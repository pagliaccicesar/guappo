import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";


const firebaseConfig = {
  apiKey: "AIzaSyAJXe3uos5nMhEMJwSdAP9EHczyevRJ4kI",
  authDomain: "clasereactutn.firebaseapp.com",
  projectId: "clasereactutn",
  storageBucket: "clasereactutn.appspot.com",
  messagingSenderId: "489368461792",
  appId: "1:489368461792:web:29a2456a90d48695d60b85",
  measurementId: "G-S9L42ZLTQ5"
};

firebase.initializeApp(firebaseConfig);
// firebase.auth = firebase.auth();

export default firebase;
